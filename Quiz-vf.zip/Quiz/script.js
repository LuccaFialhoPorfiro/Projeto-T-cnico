const perguntas = [ /*<-- Dentro desta função você vai adicionar às perguntas*/
    {
        questão: "Quem pintou a Capela Cistina?",
        resposta: [
            { text: "Leonardo Da Vinci", correct: false},
            { text: "Michelangelo", correct: true},
            { text: "Rafael", correct: false},
            { text: "Donatello", correct: false},
        ]
    },
    {
        questão: "Van Gogh morreu com quantos anos?",
        resposta: [
            { text: "56", correct: false},
            { text: "28", correct: false},
            { text: "37", correct: true},
            { text: "80", correct: false},
        ]
    },
    {
        questão: "Qual a obra de arte mais cara do mundo?",
        resposta: [
            { text: "Mona Lisa", correct: false},
            { text: "A noite estrelada", correct: false},
            { text: "O grito", correct: false},
            { text: "Salvator Mundi", correct: true},
        ]
    },
    {
        questão: "A arte Pré-Histórica vai até?",
        resposta: [
            { text: "300 a.C", correct: true},
            { text: "500 a.C", correct: false},
            { text: "300 d.C", correct: false},
            { text: "450 d.C", correct: false},
        ]
    },
    {
        questão: "A arte Egípcia se caracteriza pelo cárater?",
        resposta: [
            { text: "Colorido e abstrato", correct: false},
            { text: "Técnico e sem cor", correct: false},
            { text: "Criativo e experimental", correct: false},
            { text: "Religioso e político", correct: true},
        ]
    },
    {
        questão: "Qual desses faz parte da arquitetura Mesopotâmia?",
        resposta: [
            { text: "Pirâmides", correct: false},
            { text: "Zigurates", correct: true},
            { text: "Coliseus", correct: false},
            { text: "Panteão", correct: false},
        ]
    },
    {
        questão: "As artes Clássicas são compostas por?",
        resposta: [
            { text: "Pintura", correct: true},
            { text: "Animação", correct: false},
            { text: "Literatura", correct: true},
            { text: "Design", correct: false,}
        ]
    },
    {
        questão: "Os templos gregos eram divididos em:",
        resposta: [
            { text: "Naturalista, idealista e clássico", correct: false},
            { text: "Fídias, Policleto e Praxíteles", correct: false},
            { text: "Arcaico, clássico e helenístico", correct: false},
            { text: "Dórica, jônica e coríntia", correct: true},
        ]
    },
    {
        questão: "A arte Romana chegou até:",
        resposta: [
            { text: "Todos os cantos da Europa, Norte da África e do Oriente Médio", correct: true},
            { text: "Somente o sul da Europa e pequenas partes da Ásia", correct: false},
            { text: "Norte e Leste da Europa e as Américas", correct: false},
            { text: "Toda a Europa, África e o Norte da Ásia", correct: false},
        ]
    },
    {
        questão: "A arte Medieval é uma derivação da:",
        resposta: [
            { text: "Arte Grega", correct: false},
            { text: "Arte Romana", correct: true},
            { text: "Arte Clássica", correct: false},
            { text: "Arte Antiga", correct: false},
        ]
    },
    {
        questão: "As Iluminuras eram:",
        resposta: [
            { text: "Mosaicos que representavam divindades", correct: false},
            { text: "Pergaminhos normalmente cobertos em ouro ou prata", correct: true},
            { text: "Um novo tipo de contrução arquitetônica", correct: false},
            { text: "Livros que falavam sobre o critianismo", correct: false},
        ]
    },
    {
        questão: "Onde a arte Rômanica era principalmente encontrada:",
        resposta: [
            { text: "Igrejas Protestantes", correct: false},
            { text: "Igrejas Cristãs", correct: false},
            { text: "Sinagogas", correct: false},
            { text: "Igrejas Católicas", correct: true},
        ]
    },
    {
        questão: "A arte Gótica tem como principal tema:",
        resposta: [
            { text: "A religião", correct: true},
            { text: "A natureza", correct: false},
            { text: "As mudanças sociais", correct: false},
            { text: "O urbano", correct: false},
        ]
    },
    {
        questão: "A arte Moderna leva como inspiração:",
        resposta: [
            { text: "A arte Medieval", correct: false},
            { text: "A arte Bizantina", correct: false},
            { text: "A arte Clássica", correct: true},
            { text: "A ciência da natureza", correct: true},
        ]
    },
    {
        questão: "A arte Barroca surgiu:",
        resposta: [
            { text: "na Ásia", correct: false},
            { text: "na Itália", correct: true},
            { text: "no Oriente Médio", correct: false},
            { text: "na África", correct: false},
        ]
    },
    {
        questão: "A arte Rococó tem uma índole:",
        resposta: [
            { text: "Hedonista e aristócratica", correct: true},
            { text: "Pragmática e simples", correct: false},
            { text: "Abstrata e suave", correct: false},
            { text: "Concreta e colorida", correct: false},
        ]
    },
    {
        questão: "A arte Romântica da ênfase:",
        resposta: [
            { text: "No futuro e na natureza", correct: false},
            { text: "No passado e urbanismo", correct: false},
            { text: "No futuro e industrialismo", correct: false},
            { text: "No passado e na natureza", correct: true},
        ]
    },
    {
        questão: "Os princípios do Neoclassicismo:",
        resposta: [
            { text: "hedonismo, a falta de moderação e materialismo", correct: false},
            { text: "moderção, soberba e romantismo", correct: false},
            { text: "moderação, equilíbrio e idealismo", correct: true},
            { text: "materialismo, romantismo e equilíbrio", correct: false},
        ]
    },
    {
        questão: "A arte Contemporânea marca:",
        resposta: [
            { text: "O fim do absolutismo", correct: true},
            { text: "O fim de governos democráticos", correct: false},
            { text: "A instauração de governos absolutistas", correct: false},
            { text: "A instauração de governos democráticos", correct: true},
        ]
    },
    {
        questão: "O Surrealismo enfatiza o papel:",
        resposta: [
            { text: "do consciente no papel criativo", correct: false},
            { text: "do inconsciente no papel criativo", correct: true},
            { text: "do eu no papel criativo", correct: false},
            { text: "do ego no papel criativo", correct: false},
        ]
    },
    {
        questão: "O Dadaismo era utilizado para mostrar:",
        resposta: [
            { text: "O real, o racional e o protesto antiburguês", correct: false},
            { text: "O descontentamento com a violência, guerra e o nacionalismo", correct: true},
            { text: "O absurdo, a irracionalidade e o protesto antiburguês", correct: true},
            { text: "O apoio ao nacionalismo e os sacríficios da guerra", correct: false},
        ]
    },
    {
        questão: "Um dos artistas mais famosos do Cubismo é:",
        resposta: [
            { text: "Edvard Munch", correct: false},
            { text: "Van Gogh", correct: false},
            { text: "Salvador Dali", correct: false},
            { text: "Pablo Picasso", correct: true},
        ]
    },
    {
        questão: "Um dos artistas mais famosos do Expressionismo é:",
        resposta: [
            { text: "Salvador Dali", correct: false},
            { text: "Van Gogh", correct: true},
            { text: "Pablo Picasso", correct: false},
            { text: "Michelangelo", correct: false},
        ]
    },
    {
        questão: "Os seguidores do Futurismo rejeitavam:",
        resposta: [
            { text: "O moralismo e o futuro", correct: false},
            { text: "O moralismo e o passado", correct: true},
            { text: "O imoralismo e o passado", correct: false},
            { text: "O imoralismo e o futuro", correct: false},
        ]
    },
    
    
    
    
    
    
    
    
    
    
    
    

    
];

const questãoElement = document.getElementById("questão");
const respostaButton = document.getElementById("resposta");
const próximoButton = document.getElementById("próximo-btn")

let questãoAtualIndex = 0;
let pontuação = 0;

function começarQuiz(){
    perguntaAtualIndex = 0;
    pontuação = 0;
    próximoButton.innerHTML = "próximo";
    mostrarQuestão();
}

function mostrarQuestão(){
    resetar();
    let questãoAtual = perguntas[questãoAtualIndex];
    let questãoNo = questãoAtualIndex + 1;
    questãoElement.innerHTML = questãoNo + ". " + questãoAtual.questão;

    questãoAtual.resposta.forEach(resposta =>{
        const button = document.createElement("button")
        button.innerHTML = resposta.text;
        button.classList.add("btn");
        respostaButton.appendChild(button);
        if(resposta.correct)
        {
            button.dataset.correct = resposta.correct;
        }
        button.addEventListener("click", selecionarResposta)
    })
}

function resetar(){
    próximoButton.style.display = "none";
    while(respostaButton.firstChild){
        respostaButton.removeChild(respostaButton.firstChild);
    }
}

function selecionarResposta(e){
    const selectedBtn = e.target;
    const Certo = selectedBtn.dataset.correct === "true";
    if(Certo){
        selectedBtn.classList.add("correto");
        pontuação ++;
    }else{
        selectedBtn.classList.add("incorreto");
    }
    Array.from(respostaButton.children).forEach(button => {
        if(button.dataset.correct === "true"){
            button.classList.add("correto")
        }
        button.disabled = "true";
    });
    próximoButton.style.display = "block";
}

function mostrarPontuação(){
    resetar();
    questãoElement.innerHTML = `Você acertou ${pontuação} de ${perguntas.length} questões!`;
    próximoButton.innerHTML = "Jogar de Novo";
    próximoButton.style.display = "block"
}

function handleNextButton(){
   questãoAtualIndex++;
   if(questãoAtualIndex < perguntas.length){
       mostrarQuestão();
   }else{
      mostrarPontuação();
   }
}


próximoButton.addEventListener("click", ()=>{
   if(questãoAtualIndex < perguntas.length){
      handleNextButton();
   }else{
      começarQuiz();
   }
});

começarQuiz();